clc
clear all
image1 = imread('C:\Users\CHUCH\Desktop\IMAGE PROCESSING USING MATLAB\Histogram\Scene.jpg');
Histogram = histeq(image1);
subplot(2,2,1); imshow(image1); title('Original Image');
subplot(2,2,2); imshow(Histogram); title('Histogram Equalized image');
subplot(2,2,3); imhist(image1); title('Histogram of Original Image');
subplot(2,2,4); imhist(Histogram); title('Histogram of Equalized Image');
