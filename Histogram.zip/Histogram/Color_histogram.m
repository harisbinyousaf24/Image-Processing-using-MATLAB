%Color histogram
clc
clear all
image1 = imread('C:\Users\CHUCH\Desktop\IMAGE PROCESSING USING MATLAB\Histogram\Scene.jpg');
image2 = rgb2hsv(image1);
Histogram = histeq(image2(:,:,2));
image2(:,:,2) = Histogram;
image3 = hsv2rgb(image2);

subplot(2,2,1); imshow(image1); title('Original Image');
subplot(2,2,2); imshow(image2); title('Color Histogram');
subplot(2,2,3); imhist(image1); title('Histogram of Original Image');
subplot(2,2,4); imhist(image2); title('Histogram of color Image');
