%Histogram analysis
%An image histogram is a type of histogram
%that acts as a graphical representation of 
%the tonal distribution in a digital image. 
%It plots the number of pixels for each 
%tonal value. By looking at the histogram 
%for a specific image a viewer will be able
%to judge the entire tonal distribution 
%at a glance
clc
clear all
image1 = imread('C:\Users\CHUCH\Desktop\IMAGE PROCESSING USING MATLAB\Histogram\Panda.jpg');
subplot(1,2,1); imshow(image1);
subplot(1,2,2); imhist(image1);