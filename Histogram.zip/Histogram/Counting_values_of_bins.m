clc
clear all
image1 = imread('C:\Users\CHUCH\Desktop\IMAGE PROCESSING USING MATLAB\Histogram\Panda.jpg');
[counts, bins] = imhist(image1);
%Value of bin at specific pixel
counts(10)
counts(30)