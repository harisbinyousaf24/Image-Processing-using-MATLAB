%Histogra matching
clc
clear all
image1 = imread('C:\Users\CHUCH\Desktop\IMAGE PROCESSING USING MATLAB\Histogram\Scene.jpg');
Match = 0:255;
Histogram = histeq(image1,Match);
subplot(2,2,1); imshow(image1); title('Original Image');
subplot(2,2,2); imshow(Histogram); title('Histogram Matched image');
subplot(2,2,3); imhist(image1); title('Histogram of Original Image');
subplot(2,2,4); imhist(Histogram); title('Histogram of Matched Image');
